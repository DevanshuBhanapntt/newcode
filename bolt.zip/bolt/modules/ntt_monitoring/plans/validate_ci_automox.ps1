﻿#Evaluate credentials returned
param($org_id,$serverid,$api_key,$username,$password,$page,$count)
if($password)
{"Credentials : Automox credentials retrieved"

#configure credentials object
$notes=$notes.split(":")
$apikey=$notes[1]
$password = convertto-securestring -String "$password" -AsPlainText -Force 
$automoxcred=New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $username, $password

#get server information
$serverlookup="https://console.automox.com/api/servers/$($serverid)?o=$org$([char]38)api_key=$apikey"
$data=Invoke-RestMethod -URI $serverlookup -Credential $automoxcred -ErrorAction SilentlyContinue -ErrorVariable badcall
if($badcall)
{
 "ERROR : $badcall"
 Exit 1
}


#server found?
if ($data)
 {
  "Success : $serverid found in org $org"
  $servername=$data.name
  $fqdns=$data.detail.FQDNs
  $osfamily=$data.os_family
  $serverorg=$data.organization_id
  $pendingpatches=$data.pending_patches
  $patches=$data.patches
  $last_update_time=$data.last_update_time
  $lastcheckin=$data.last_checkin_time
  $nextpatchtime=$data.next_patch_time
  "Server Name : $servername"
  "FQDNs : $fqdns"
  "OS Family : $osfamily"
  "Org ID : $serverorg"
  "Pending Patches : $pendingpatches"
  "Patches : $patches"
  if($last_update_time.length -eq 0){"ERROR : Automox has not patched $servername successfully"}
  else{"Last Successful Patch Time (GMT) : $last_update_time"}
  "Last Checkin (GMT) : $lastcheckin"
  "Next Patch Time (GMT) : $nextpatchtime"

  #get patch reporting events for server
  $eventlookup="https://console.automox.com/api/events?o=$org$([char]38)api_key=$apikey"   #org limiter does work, although not documented
  $data=Invoke-RestMethod -URI $eventlookup -Credential $automoxcred
  $data=$data|where {$_.server_id -ieq $serverid -and $_.name -ieq "system.policy.action" -and $_.create_time -ige $last_update_time}
  #$lastupdatetime is the last successful update time, if failed attempts have occurred later than that time, may return multiple entries
  if($data.count -gt 0){$data=$data[0]}
  if($data.data.status -eq 0)
  {
   "Event : $($data.id)"
   "Patch status code : $($data.data.status)"
    $patchlist=$data.data.text
    $test=$patchlist.substring(19,$patchlist.length-19)
    "Applied Patches : $test"
  }
  elseif($data.data.status -eq 1)
  {
   "Event : $($data.id)"
   "Latest failed patch attempt (GMT) : $($data.create_time)"
   "Patch status code : $($data.data.status)"
   "ERROR : At least one patch installation failed"
    $patchlist=$data.data.text
    #$test=$patchlist.substring(19,$patchlist.length-19)
    "ERROR : $patchlist"
  }
  else{"ERROR : No current patching event found for $servername in org $org"}
}
else {"ERROR : $serverid not found in org $org"}
}
else {"ERROR : Unable to retrieve Automox credentials, no attempt to retrieve information"}