param($computer)
$hname = $env:computername
echo "Hostname of LAP server -> $hname"

if ([string]::IsNullOrEmpty($computer)) {
                                         write-host "ERROR : No computer name supplied"
                                         $th = 0
                                         write-host "totalhours : $th"
                                         exit 0  
                                        }
else {
  echo "Configuration Item hostname  -> $computer"
  Try {
    $ipaddress = [System.Net.Dns]::GetHostAddresses($computer)|?{$_.scopeid -eq $null}|%{$_.ipaddresstostring}|select -First 1
    echo "Configuration Item IP Address -> $ipaddress"
    Try {
      $wmi = Get-WmiObject -ComputerName $ipaddress -Query "SELECT LastBootUpTime FROM Win32_OperatingSystem" -ErrorAction Stop
      $now = Get-Date
      $boottime = $wmi.ConvertToDateTime($wmi.LastBootUpTime)
      $uptime = $now - $boottime
      $th = $uptime.totalhours
      $ts = [math]::truncate($uptime.totalseconds)
        } 
    catch { 
        Write-Host "ERROR : Unable to retrieve information from $computer."
        $output=$_.Exception|Out-String
        $output="ERROR : "+$output
        write-host $output
        $th = 0 
        write-host "totalhours : $th"
# testing multiple adapters       exit 0
exit 1 
           }
       }
  catch {
    Write-Host "ERROR : Remote host $computer could not be resolved."
	$output=$_.Exception|Out-String
    $output="ERROR : "+$output
    write-host $output
    $th = 0 
    write-host "totalhours : $th"
  #this used to be exit 0, but was changed to one to force through multiple PowerShell adapters in the wrapping process if communication fails 
    exit 1
	  }
if (($th -lt 0) -or ($ts -lt 0))
 {
	$th = .01
	$ts = 5
 }
  write-host "totalhours : $th"
  write-host "totalsecs  : $ts"
     }